Read Me

 - To run the compiled Asteroid Fighter, simply open up the file Asteroid_Fighter.jar and play!
 - Our uncompiled source java files are located in the folder src/ along with our class diagram


Austin So, Carl Lyss, Van Tran, Stephen Booth

27/06/2017



